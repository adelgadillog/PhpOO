<div class="box-principal">
	<h3 class="titulo">Editar Seccion <hr></h3>
	<div class="panel panel-success">
		<div class="panel-heading">
			<h3 class="panel-tittle">
				Editar una seccion
			</h3>
		</div>
		<div class="panel-body">
			<div class="row">
				<div class="col-md-1"></div>
				<div class="col-md-10">

					<form action="" method="POST" enctype="multipart/form-data" class="form-horizontal">
						<div class="form-group">
							<label for="inputEmail" class="control-label">Nombre de la seccion
							</label>
							<input value="<?php echo $datos['nombre']; ?>" type="text" name="nombre" class="form-control" required>
							<input value="<?php echo $datos['id']; ?>" type="hidden" name="id" class="form-control" required>
						</div>
						
						<div class="form-group">
						<a class="btn btn-primary" href="<?php echo URL;?>secciones">Volver</a>
							<button type="submit" class="btn btn-success">Actualizar</button>
							<button type="reset" class="btn btn-warning">Limpiar</button>
						</div>
					</form>
				</div>
				<div class="col-md-1"></div>
			</div>
		</div>
	</div>
</div>