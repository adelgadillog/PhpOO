<?php $secciones = $estudiantes->listarSecciones(); ?>
<div class="box-principal">
	<h3 class="titulo">Editar Estudiantes <?php echo $datos['nombre'];?><hr></h3>
	<div class="panel panel-success">
		<div class="panel-heading">
			<h3 class="panel-tittle">
				Editar estudiante
			</h3>
		</div>
		<div class="panel-body">
			<div class="row">
				<div class="col-md-3">
					<div class="panel panel-default">
						<div class="panel-body">
							<img src="<?php echo URL; ?>Views/template/imagenes/avatars/<?php echo $datos['imagen'];?>" alt="" class="img-responsive">
						</div>
					</div>
				</div>
				<div class="col-md-9">
					<form action="" method="POST" enctype="multipart/form-data" class="form-horizontal">
						<div class="form-group">
							<label for="inputEmail" class="control-label">Nombre del estudiante
							</label>
							<input type="text" name="nombre" value="<?php echo $datos['nombre'];?>" class="form-control" required>
						</div>
						<div class="form-group">
							<label for="inputEdad" class="control-label">Edad
							</label>
							<input type="number" name="edad" value="<?php echo $datos['edad'];?>"class="form-control" required>
						</div>
						<div class="form-group">
							<label for="inputPromedio" class="control-label">Promedio
							</label>
							<input type="number" name="promedio" value="<?php echo $datos['promedio'];?>"class="form-control" required>
						</div>
						<div class="form-group">
							<label for="inputSeccion" class="control-label">Seccion (<b>Seccion Actual:<?php echo $datos['nombre_seccion'];?></b>)
							</label>
							<select name="id_seccion" id="id_seccion" class="form-control">
								<?php
									while($row = mysqli_fetch_array($secciones)){?>
										<option value="<?php echo $row['id'] ?>"><?php echo $row['nombre']?></option>
								<?php	}

								 ?>
							</select>
						</div>

						<input type="hidden" name="id" id="id" value="<?php echo $datos['id'];?>" >
						<div class="form-group">
							<a class="btn btn-primary" href="<?php echo URL;?>estudiantes">Volver</a>
							<button type="submit" class="btn btn-success">Actualizar</button>
							<button type="reset" class="btn btn-warning">Limpiar</button>
						</div>
					</form>
				</div>
			
			</div>
		</div>
	</div>
</div>