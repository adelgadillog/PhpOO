<?php 
/*desarrollar una simple crud, el cual va a adminsitrar los estudiantes de un salon, este estara divido en secciones. Ademas cada estudiante va a contener hasta su imagen (nombre, apellido, edad, sexo, fecha de nacimiento, imagen)*/
/*clases: Estudiante, Seccion, Conexion*/
/*vistas: Agregar, Editar, Eliminarm Ver*/
//Archivos .htaccess, autoload. index.php
define('DS',DIRECTORY_SEPARATOR);
define('ROOT', realpath(dirname(__FILE__)).DS);
define('URL',"http://localhost/PHP_OO/proyecto/");
require_once "Config/Autoload.php";
Config\Autoload::run();
require_once "Views/template.php";
Config\Enrutador::run(new Config\Request());


?>